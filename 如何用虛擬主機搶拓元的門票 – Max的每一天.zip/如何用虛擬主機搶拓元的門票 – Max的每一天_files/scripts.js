jQuery( function ( $ ) {
	'use strict';

	var $window = $( window );
	var $body   = $( 'body' );
	var isRTL   = $body.hasClass('rtl');

	/* -----------------------------------------
	 Responsive Menu Init
	----------------------------------------- */
	var $navWrap          = $( '.nav' );
	var $navSubmenus      = $navWrap.find( 'ul' );
	var $mainNav          = $( '.navigation-main' );
	var $mobileNav        = $( '.navigation-mobile-wrap' );
	var $mobileNavTrigger = $('.mobile-nav-trigger');
	var $mobileNavDismiss = $('.navigation-mobile-dismiss');

	$mainNav.each( function () {
		var $this = $( this );
		$this.clone()
			.find('> li')
			.removeAttr( 'id' )
			.appendTo( $mobileNav.find( '.navigation-mobile' ) );
	} );

	$mobileNav.find( 'li' )
		.each(function () {
			var $this = $(this);
			$this.removeAttr( 'id' );

			if ( $this.find('.sub-menu').length > 0 ) {
				var $button = $( '<button />', {
					class: 'menu-item-sub-menu-toggle',
				} );

				$this.find('> a').after( $button );
			}
		});

	$mobileNav.find('.menu-item-sub-menu-toggle').on( 'click', function ( event ) {
		event.preventDefault();
		var $this = $(this);
		$this.parent().toggleClass('menu-item-expanded')
	} );

	$mobileNavTrigger.on( 'click', function ( event ) {
		event.preventDefault();
		$body.addClass('mobile-nav-open');
		$mobileNavDismiss.focus();
	} );

	$mobileNavDismiss.on( 'click', function ( event ) {
		event.preventDefault();
		$body.removeClass('mobile-nav-open');
		$mobileNavTrigger.focus();
	} );

	/* -----------------------------------------
	 Mobile nav focus trap
	----------------------------------------- */
	(function () {
		var $mobileMenuDismiss = $( '.navigation-mobile-dismiss' );
		var $mobileMenu = $( '.navigation-mobile' );

		var getLastMenuItem = function () {
			return $mobileMenu.find('li:visible:last-child').last().find('> a');
		};

		$body.on('keydown', function ( event ) {
			if ( !$body.hasClass( 'mobile-nav-open' ) ) {
				return;
			}

			var tabKey = event.keyCode === 9;
			var shiftKey = event.shiftKey;
			var $lastElement = getLastMenuItem();
			var $firstElement = $mobileMenuDismiss;
			var $activeElement = $(document.activeElement);

			if ( ! shiftKey && tabKey && $lastElement.is( $activeElement ) ) {
				event.preventDefault();
				$firstElement.focus();
			}

			if ( shiftKey && tabKey && $firstElement.is( $activeElement ) ) {
				event.preventDefault();
				$lastElement.focus();
			}
		});
	})();


	/* -----------------------------------------
	Menu classes based on available free space
	----------------------------------------- */
	function setMenuClasses() {
		if ( ! $navWrap.is( ':visible' ) ) {
			return;
		}

		var windowWidth = $window.width();

		$navSubmenus.each( function () {
			var $this   = $( this );
			var $parent = $this.parent();
			$parent.removeClass( 'nav-open-left' );
			var leftOffset = $this.offset().left + $this.outerWidth();

			if ( leftOffset > windowWidth ) {
				$parent.addClass( 'nav-open-left' );
			}
		} );
	}

	setMenuClasses();

	var resizeTimer;

	$window.on( 'resize', function () {
		clearTimeout( resizeTimer );
		resizeTimer = setTimeout( function () {
			setMenuClasses();
		}, 350 );
	} );

	/* -----------------------------------------
	Main nav smooth scrolling
	----------------------------------------- */
	(function () {
		var $mainNavParents = $mainNav.find( '> li' );
		var $mainMenuNavs = $mainNav.find( 'a[href*="#"]' );
		var $mobileMenuNavs = $mobileNav.find( 'a[href*="#"]' );
		var $navs = $mainMenuNavs.add( $mobileMenuNavs ).filter( function () {
			var href = $( this ).attr( 'href' );
			return href !== '#' &&
				href !== 'http://#' &&
				href !== 'https://#' &&
				href !== '#mobilemenu' &&
				href !== '#mm-0';
		} );

		if ( !$navs.length ) {
			return;
		}

		$navs.on( 'click', function ( event ) {
			event.preventDefault();
			var $target = $( this.hash );

			if ( $target.length && ! $target.hasClass('elementor-menu-anchor' ) ) {
				$( 'html, body' ).animate({
					scrollTop: $target.offset().top - 85,
				}, 500 );
			}
		} );

		// Mark nav items active on scroll
		var navIds = $navs
			.map(function () {
				var id = $( this ).attr( 'href' ).split( '#' )[ 1 ];
				return '#' + id;
			})
			.get();
		var $contentSections = $( navIds.join( ',' ) );

		var scrollTimer;

		$window.on('scroll', ( function () {
			clearTimeout(scrollTimer);

			scrollTimer = setTimeout( function () {
				var scrollDistance = $window.scrollTop();

				// Assign active class to nav links while scolling
				$contentSections.each( function () {
					var $this = $( this );

					if ( scrollDistance >= $this.offset().top - 150 ) {

						var $sectionNav = $mainMenuNavs.filter( function () {
							return $( this ).attr( 'href' ).indexOf( $this.attr( 'id' ) ) > -1;
						} ).first();
						$mainNavParents.removeClass( 'current-menu-item' );
						$sectionNav.parent().addClass( 'current-menu-item' );
					}
				} );
			}, 150 );
		})).scroll();
	}());

	/* -----------------------------------------
	General Focus trapping
	----------------------------------------- */
	$('[data-set-focus]').each( function () {
		var $this = $(this);
		var selector = $this.data('set-focus');
		var $element = $(selector);

		$this.on( 'blur', function () {
			if ( $element.length ) {
				$element.focus();
			}
		} );
	} );

	/* -----------------------------------------
	 Sticky Header
	 ----------------------------------------- */
	(function () {
		var $header = $('.header-sticky');
		var stickyMobileDisabled = $header.hasClass('header-sticky-mobile-disabled');

		if ( !$.fn.sticky || !$header.length ) {
			return;
		}

		var md = stickyMobileDisabled && new MobileDetect( window.navigator.userAgent );
		var isTabletOrMobile = stickyMobileDisabled && (!!md.tablet() || !!md.mobile());

		var $headOutro      = $header.find( '.head-outro' );
		var $headMast       = $header.find( '.head-mast' );
		var $sticky         = $headOutro.length > 0 ? $headOutro : $headMast;
		var $logoImg        = $( '.site-branding img' );
		var logoOriginalSrc = $logoImg.attr( 'src' );
		var logoNormal      = $logoImg.data( 'logo' );
		var logoSticky      = $logoImg.data( 'logo-alt' );
		var stickyAlt       = $logoImg.data( 'sticky-logo' ) === 'alt';
		var resizeTimer;

		if ( stickyMobileDisabled ) {
			$window.on( 'resize', function () {
				clearTimeout(resizeTimer);
				resizeTimer = setTimeout(function () {
					var width = $window.width();

					if ( width > 1024 && !isTabletOrMobile ) {
						stick();
					} else {
						unstick();
					}
				}, 400 );
			} );
		}

		function stick() {
			if ( isTabletOrMobile && ( $window.width() < 1025 || isTabletOrMobile ) ) {
				return;
			}

			$sticky.sticky( {
				topSpacing: 0,
				responsiveWidth: true,
				className: 'head-stuck',
				wrapperClassName: $header.hasClass( 'header-fixed' )
					? 'header-sticky-fixed'
					: 'header-sticky-wrapper',
				zIndex: 150,
			} );

			$sticky.on( 'sticky-start', onHeaderStick );
			$sticky.on( 'sticky-end', onHeaderUnstick );
		}

		function unstick() {
			$sticky.unstick();
		}

		// When the header sticks we always want to be showing
		// the normal logo except if the "show alt logo on sticky" is enabled.
		var onHeaderStick = function () {
			if ( ! logoNormal ) {
				return;
			}

			if ( stickyAlt ) {
				$logoImg.attr( 'src', logoSticky );
			} else {
				$logoImg.attr( 'src', logoNormal );
			}
		};

		// When the header unsticks we want to revert to the original
		// logo (whether it's the normal or the alt one).
		var onHeaderUnstick = function () {
			if ( ! logoNormal || ! logoOriginalSrc ) {
				return;
			}

			$logoImg.attr( 'src', logoOriginalSrc );
		};

		stick();
	}());

	/* -----------------------------------------
	 Back to top button
	 ----------------------------------------- */
	var $btnTop = $( '.btn-to-top' );

	if ( $btnTop.length > 0 ) {
		var scrollTimer;

		$btnTop.on( 'click', function ( event ) {
			event.preventDefault();

			$( 'html, body' ).animate( { scrollTop: 0 }, 'fast' );
		} );

		$window.on( 'scroll', function ( e ) {
			clearTimeout( scrollTimer );
			scrollTimer = setTimeout( function () {
				if ( $window.scrollTop() > 400 ) {
					$btnTop.addClass( 'btn-to-top-visible' );
				} else {
					$btnTop.removeClass( 'btn-to-top-visible' );
				}
			}, 250 );
		} );
	}

	/* -----------------------------------------
	 Header Search Toggle
	 ----------------------------------------- */
	var $searchTrigger  = $( '.global-search-form-trigger' );
	var $searchDismiss  = $( '.global-search-form-dismiss' );
	var $headSearchForm = $( '.global-search-form' );

	function dismissHeadSearch(e) {
		if ( e ) {
			e.preventDefault();
		}

		$headSearchForm.removeClass( 'global-search-form-expanded' );
		$body.focus();
	}

	function displayHeadSearch( e ) {
		if ( e ) {
			e.preventDefault();
		}

		$headSearchForm
			.addClass( 'global-search-form-expanded' )
			.find( 'input' )
			.focus();
	}

	function isHeadSearchVisible() {
		return $headSearchForm.hasClass( 'global-search-form-expanded' );
	}

	$searchTrigger.on( 'click', displayHeadSearch );
	$searchDismiss.on( 'click', dismissHeadSearch );

	/* Event propagations */
	$( document ).on( 'keydown', function ( e ) {
		e = e || window.e;
		if ( e.keyCode === 27 && isHeadSearchVisible() ) {
			dismissHeadSearch( e );
		}
	} );

	$body
		.on( 'click', function ( e ) {
			if ( isHeadSearchVisible() ) {
				dismissHeadSearch();
			}
		} )
		.find( '.global-search-form, .global-search-form-trigger' )
		.on( 'click', function ( e ) {
			e.stopPropagation();
		} );

	$window.on('load', function () { } );
} );

/**
 * File skip-link-focus-fix.js.
 *
 * Helps with accessibility for keyboard only users.
 *
 * Learn more: https://git.io/vWdr2
 */
( function() {
	var isIe = /(trident|msie)/i.test( navigator.userAgent );

	if ( isIe && document.getElementById && window.addEventListener ) {
		window.addEventListener( 'hashchange', function() {
			var id = location.hash.substring( 1 ),
				element;

			if ( ! ( /^[A-z0-9_-]+$/.test( id ) ) ) {
				return;
			}

			element = document.getElementById( id );

			if ( element ) {
				if ( ! ( /^(?:a|select|input|button|textarea)$/i.test( element.tagName ) ) ) {
					element.tabIndex = -1;
				}

				element.focus();
			}
		}, false );
	}
}() );
